/* index */
//放大
$(document).on('click','#alert_info>.list-box>.title-box>.title>.magnify',function(){
    var getobj = $(this).parent().parent().parent();
    var id = getobj.attr("id");//获取ID
    historypush(id);
    if(id == "tomorrow" && (tomorrow_tab + today_tab) == 0){
        tomorrow_tab = 1;
        $("#" + id).css("opacity","0");
        $('.magnify-box').fadeIn(300);
        $('#pannel-index>.pannel>.shade').fadeIn(300);
        load_alert_thing(0);
        // $("#pannel-index>.pannel>.magnify-box>.title-box>.title>.name").text("明日过期");
    }
    else if(id == "today" && (tomorrow_tab + today_tab) == 0){
        today_tab = 1;
        $("#" + id).css("opacity","0");
        $('.magnify-box').fadeIn(300);
        $('#pannel-index>.pannel>.shade').fadeIn(300);
        load_alert_thing(1);
        // $("#pannel-index>.pannel>.magnify-box>.title-box>.title>.name").text("今日过期");
    }
});

//缩小
$(document).on('click','.magnify-box>.title-box>.title>.shrink',function(){
    window.history.back();
});

//物品添加
$(document).on('click','#quickentry-1', function(){
    $("#thingadd-box>.add-box").css("opacity","1");
    $("#thingadd-box").css("transform","translateX(0%)");
    $("#thingadd-box>.head>.title>span").html("物品添加");
    setTimeout(function() {$("#loading_page").fadeIn(300); }, 100);
    setTimeout(function() {addthing_clear(); }, 300);//清空信息
    
    $("#thingadd-box>.add-box>.btn-box>.btn.edit").css("display","none");
    $("#thingadd-box>.add-box>.btn-box>.btn.submit").css("display","block");
    thingadd_box_open = 1;
    historypush("#thingadd-box>.head>.return-box");
});

//物品列表
$(document).on('click','#quickentry-2', function(){
    page = 0;
    list_clear_thing('#thinglist-box>.list-box','thinglist-loading-box');
    thinglist_open = 1;
    thing_type = 7;
    thing_c_id = 0;
    thing_name_key = "";
    thing_creat = ""; 
    sort_type = 0;
    sort_method = 0; 
    loading_page = 1;
    page_items = -1;
    sift.locatePosition(0,0);
    sort.locatePosition(0,0);
    sort.locatePosition(1,0);
    if($("#thinglist_tag_1").hasClass("disable")){
        $("#thinglist_tag_1").removeClass("disable");
    }
    if($("#thinglist_tag_2").hasClass("disable")){
        $("#thinglist_tag_2").removeClass("disable");
    }
    if($("#thinglist_tag_3").hasClass("disable")){
        $("#thinglist_tag_3").removeClass("disable");
    }
    $("#thing-sort").text("无排序");
    $("#thing-sift").text("不限-不限-不限");
    $("#list_class_select>.name").text("全部");
    loading_start("#thinglist-loading-box");
    
    $("#thinglist-box").css("transform","translateX(0%)");
    historypush("#thinglist-box>.head>.return-box");
    setTimeout(function() {$("#loading_page").fadeIn(300); }, 300);
    setTimeout(function() {get_thing(user_id,thing_type,thing_c_id,thing_name_key,thing_creat,sort_type,sort_method,++page); }, 500);
});

//物品查询
$(document).on('click','#quickentry-3', function(){
    $("#thingsearch-box").css("transform","translateX(0%)");
    searchlist_open = 1;
    
    page = 0;
    list_clear_thing('#search-box>.list-box','searchlist-loading-box');
    thing_type = 7;
    thing_c_id = 0;
    thing_name_key = "";
    thing_creat = "0000-00-00"; 
    sort_type = 0;
    sort_method = 0; 
    page_items = -1;
    
    $("#search-item-name").val("");
    $("#search-box-select>.text").text("全部");
    search_box_select.locatePosition(0,0);

    if($("#searchlist_tag_1").hasClass("disable")){
        $("#searchlist_tag_1").removeClass("disable");
    }
    if($("#searchlist_tag_2").hasClass("disable")){
        $("#searchlist_tag_2").removeClass("disable");
    }
    if($("#searchlist_tag_3").hasClass("disable")){
        $("#searchlist_tag_3").removeClass("disable");
    }
    
    loading_end("#searchlist-loading-box");

    historypush("#thingsearch-box>.head>.return-box");
});

//提交获取
$(document).on('click','#search-sub', function(){
    var tag1,tag2,tag3;
    tag1 = 1;
    tag2 = 2;
    tag3 = 4;
    if($("#searchlist_tag_3").hasClass("disable")){
        tag1  = 0;
    }
    if($("#searchlist_tag_2").hasClass("disable")){
        tag2  = 0;
    }
    if($("#searchlist_tag_1").hasClass("disable")){
        tag3  = 0;
    }
    var name = htmlEncodeJQ($("#search-item-name").val());
    var classname = $("#search-box-select>.text").text();
    var class_id = get_class_name(classname);
    if(class_id == -1){
        thing_c_id = 0;
    }
    else{
        thing_c_id = classes[class_id].c_id;
    }
    if(tag1 + tag2 + tag3 == 0){
        add_msg("必须选择至少一种类型",2);
        return 0;
    }
    page = 0;
    list_clear_thing('#search-box>.list-box','searchlist-loading-box');
    thing_type = tag1 + tag2 + tag3;
    thing_name_key = name;
    page_items = -1;
    if(loading_page == 0){
        loading_page = 1;
        $("#loading_page").fadeIn(300);
        get_thing(user_id,thing_type,thing_c_id,thing_name_key,thing_creat,sort_type,sort_method,++page);
    }
    if(search_open == 1){
       window.history.back(); 
    }
});

//标签状态更换
$(document).on('click','#search-item-box>.item-box>.item>.condition>.tag', function(){
    if($(this).hasClass("disable")){
        $(this).removeClass("disable");
    }
    else{
       $(this).addClass("disable"); 
    }
});


//foot切换主页面
$(document).on('click','.footer>.tabs>.tabs-item', function(){
    $(this).addClass("this").siblings().removeClass("this");
    var id = $(this).attr("id");
    if(id != page_now){
        if(id == "to_index"){
            $(getpageid(page_now)).addClass("pannel-hide-r").removeClass("pannel-show-r pannel-show-l pannel-hide-l");
            page_now = id;
            $(getpageid(id)).addClass("pannel-show-r").removeClass("pannel-hide-r pannel-hide-l pannel-show-l");
        }
        else if(id == "to_mine"){
            $(getpageid(page_now)).addClass("pannel-hide-l").removeClass("pannel-show-r pannel-show-l pannel-hide-r");
            page_now = id;
            $(getpageid(id)).addClass("pannel-show-l").removeClass("pannel-hide-r pannel-hide-l pannel-show-r");
        }
        else if(page_now == "to_index"){
            $(getpageid(page_now)).addClass("pannel-hide-l").removeClass("pannel-show-r pannel-show-l pannel-hide-r");
            page_now = id;
            $(getpageid(id)).addClass("pannel-show-l").removeClass("pannel-hide-r pannel-hide-l pannel-show-r");
        }
        else{
            $(getpageid(page_now)).addClass("pannel-hide-r").removeClass("pannel-show-r pannel-show-l pannel-hide-l");
            page_now = id;
            $(getpageid(id)).addClass("pannel-show-r").removeClass("pannel-hide-r pannel-hide-l pannel-show-l");
        }
    }
    if(require_box_open == 1){
        window.history.back();
    }
});

//控制head隐藏头像菜单打开关闭
$(document).on('click','.header>.avatar-box', function(){
    var open_menu = {
        "opacity": '1',
        "left":'calc(100% - 125px)'
    };
    var close_menu = {
        "opacity": '0',
        "left":'100%'
    };
    if(head_box_open == 0){
        head_box_open = 1;
        $(this).parent().children('#menu-mini').css(open_menu);
    }
    else{
        head_box_open = 0;
        $(this).parent().children('#menu-mini').css(close_menu);
    }
});

/* 分类列表主页 */
//打开添加箱子盒子
$(document).on('click','#pannel-boxlist>.tool-box>.toolbtn>.ans', function(){
    var id = $(this).parent().attr("id");
    if(id == "addbtn"){
        $("#addclass-box>.head>.title>span").text("添加箱子");
        addclass_clear();
        $('#pannel-boxlist>.shade').fadeIn();
        $("#addclass-box").css("transform","translateY(-100%)");
        historypush("#addclass-box>.head>.return-box");
        addclass_box_open = 1;	//底部添加物品类盒子设置为打开状态
    }
});

//箱子添加返回键
$(document).on('click','#addclass-box>.head>.return-box',function(){
    if(addclass_box_open || editclass_box_open){
        window.history.back();
    }
});

//箱子添加取消键
$(document).on('click','#cancel_addclass',function(){
    if(addclass_box_open || editclass_box_open){
        window.history.back();
    }
});

//备注内容监听
$(document).on("input propertychange",'#addclass_beizhu',function() {
    $("#addclass_beizhu").val($("#addclass_beizhu").val().replace(/[\r\n]/g,""));//取消换行
    var $this = $(this),
        _val = $this.val(),
        count = $this.val().length;
    $("#addclass_beizhu_len").text(count + "/100");
    if(editclass_box_open == 1)$("#sub_addclass").css("background-color","rgba(0,102,0,0.7)");
    if(count >= 100){
        $("#addclass_beizhu_len").addClass("type-danger").removeClass("type-disable");
    }
    else{
        $("#addclass_beizhu_len").addClass("type-disable").removeClass("type-danger");
    }
});

//名称内容监听
$(document).on("input propertychange",'#addclass_name',function() {
    $("#addclass_name").val($("#addclass_name").val().replace(" ",""));//取消换行
    var $this = $(this),
        _val = $this.val(),
        count = $this.val().length;
    $("#addclass_name_len").text(count + "/10");
    if(count > 0){
        $("#sub_addclass").css("background-color","rgba(0,102,0,0.7)");
    }
    else{
        $("#sub_addclass").css("background-color","rgba(200,200,200,0.7)");
    }
    if(count == 10){
        $("#addclass_name_len").addClass("type-danger").removeClass("type-disable");
    }
    else{
        $("#addclass_name_len").addClass("type-disable").removeClass("type-danger");
    }
});

//表单提交实现添加
$(document).on('click','#sub_addclass',function(){
    var name = $("#addclass_name").val();
    var beizhu = $("#addclass_beizhu").val();
    if(name != ""){
        if(editclass_box_open == 0){
            add_class(user_id,name,beizhu);
        }
        else{
            edit_class(classes[edit_class_id].c_id,name,beizhu);
        }
        
    }
});

//打开编辑状态
$(document).on('click','#pannel-boxlist>.card-box>.card>.button>.edit',function(){
    var c_id = $(this).parent().parent().attr("id").substring(2);
    edit_class_id = get_class_id(c_id);
    if(addclass_box_open == 0){
        $("#addclass-box>.head>.title>span").text("编辑箱子");
        addclass_set("name","beizhu");
        $('#pannel-boxlist>.shade').fadeIn();
        $("#addclass-box").css("transform","translateY(-100%)");
        historypush("#addclass-box>.head>.return-box");
        addclass_box_open = 1;  
        editclass_box_open = 1;
        $("#loading_page").fadeIn(300);
        setTimeout(function() {addclass_set(classes[edit_class_id].value,classes[edit_class_id].beizhu); }, 300);
    }
});

$(document).on('click','#pannel-boxlist>.card-box>.card>.button>.del',function(){
    var c_id = $(this).parent().parent().attr("id").substring(2);
    // var id = get_class_id(c_id);
    var code="是否确定删除，删除后该分类下的物品将移至系统默认分类中";
    add_require("确定删除吗?", code, "确定", "取消", "delc_" + c_id, "", "#pannel-boxlist>.card-box>.card");
});
//进入该分类查看
$(document).on('click','#pannel-boxlist>.card-box>.card>.tagname',function(){
    
});

/* mine */
//账号安全子页打开
$(document).on('click','#mine-safe-open', function(){
    if(mine_safe + mine_set + mine_help == 0){
        $("#mine-safe").css("transform","translateX(0%)");
        historypush("#mine-safe");
        mine_safe = 1;
    }
});

//帮助子页打开
$(document).on('click','#mine-help-open', function(){
    if(mine_safe + mine_set + mine_help == 0){
        $("#mine-help").css("transform","translateX(0%)");
        historypush("#mine-help");
        mine_help = 1;
    }
});

//设置子页打开
$(document).on('click','#mine-set-open', function(){
    if(mine_safe + mine_set + mine_help == 0){
        $("#mine-set").css("transform","translateX(0%)");
        historypush("#mine-set");
        mine_set = 1;
    }
});

//软件信息子页打开
$(document).on("click",'#open-softinfo',function() {
    if(soft_info == 0){
        $("#mine-softinfo").css("transform","translateX(0%)");
        historypush("soft_info");
        soft_info = 1;
    }
});
//关于我们子页打开
$(document).on("click",'#open-about',function() {
    if(aboutus == 0){
        $("#mine-about").css("transform","translateX(0%)");
        historypush("aboutus");
        aboutus = 1;
    }
});
//退出登录
$(document).on("click",'#open-exit',function() {
    add_require("退出提示", "确定退出登录吗？", "确定", "取消", "exit", "", "#open-exit");
});
//子页通用返回
$(document).on('click','.minepannel>.head>.return-box', function(){
    window.history.back();
});

//子页中的开关转换
/*$(document).on('click','.minepannel>.sets-box>.card>.item>.switch-box>.switch-out', function(){
    if(!$(this).is('.active')){
        $(this).addClass('active');
    }
    else{
        $(this).removeClass('active');
    }
});*/
//首页通知开关
$(document).on('click','#user_info_alert_inner', function(){
    if(switch_alert_inner == 1){
        return 0;
    }
    if(!$(this).is('.active')){
        $(this).addClass('active');
        edit_info(user_id,"u_alert_inner",1);
    }
    else{
        $(this).removeClass('active');
        edit_info(user_id,"u_alert_inner",0);
    }
});

//短信通知开关
$(document).on('click','#user_info_alert_phone', function(){
    if(switch_alert_phone == 1){
        return 0;
    }
    if(!user_info.u_phone){
        add_msg("请先绑定手机号",3);
        return 0;
    }
    if(!$(this).is('.active')){
        $(this).addClass('active');
        edit_info(user_id,"u_alert_phone",1);
    }
    else{
        $(this).removeClass('active');
        edit_info(user_id,"u_alert_phone",0);
    }
});

//邮箱通知开关
$(document).on('click','#user_info_alert_email', function(){
    if(switch_alert_email == 1){
        return 0;
    }
    if(!user_info.u_email){
        add_msg("请先绑定邮箱",3);
        return 0;
    }
    if(!$(this).is('.active')){
        $(this).addClass('active');
        edit_info(user_id,"u_alert_email",1);
    }
    else{
        $(this).removeClass('active');
        edit_info(user_id,"u_alert_email",0);
    }
});

//打开关闭修改头像隐藏的修改框
$(document).on('click','.minepannel>.sets-box>.card>#open-edit-avatar', function(){
    historypush("#edit-avatar");
    open_edit_avatar = 1;
    $("#edit-avatar").fadeIn(300);
    $("#mine-safe>.shade").fadeIn(300);
    $("#avatar-img").attr("src",user_info.u_avatar);
});

$(document).on('click','#get_avatar', function(){
    $("#file_img").click();
});

$(document).on('click','#clipicConfirm', function(){
    $("#loading_page").fadeIn(300);
});

function chooseImg(event) {
    historypush("get_avatar");
    var files = event.files || event.dataTransfer.files;
    var reader = new FileReader();
    $("#loading_page").fadeIn(300);
    reader.readAsDataURL(files[0]);
    $("#loading_page").fadeOut(300);
    reader.onload = e => {
        clipic.getImage({
            width: 100,
            height: 100,
            ratio: 16 / 16,
            src: e.target.result,
            buttonText: ['取消', '重新上传', '确定'],
            name: 'test',
            encode: 'base64', // 支持 base64、blob、file
            type: 'png',
            // quality: '0.9', // 导出图片的质量
            onDone: function (e) {
            document.getElementById('avatar-img').src = e;
            window.history.back();
            },
            onCancel: function () {
            window.history.back();
            console.log('取消裁剪')
            }
        })
    }
    event.value = '';
}

//关闭更改头像窗口
$(document).on('click','#edit-avatar>.head-box>.return', function(){
    if(open_edit_avatar == 1){
        window.history.back();
    }
});

//打开修改昵称隐藏的修改框
$(document).on('click','.minepannel>.sets-box>.card>#open-edit-name', function(){
    historypush("#edit-name");
    open_edit_name = 1;
    $("#edit-name").fadeIn(300);
    $("#mine-safe>.shade").fadeIn(300);
    $("#edit_user_name").val(user_info.u_name);
});

//昵称键入监听
$(document).on("input propertychange",'#edit_user_name',function() {
    $("#edit_user_name").val(($("#edit_user_name").val()).replace(/^\s*|\s*$/g,""));//取消换行
});

//提交昵称修改
$(document).on('click','#sub_user_name', function(){
    var new_name = $("#edit_user_name").val();
    if(new_name == ""){
        add_msg("昵称不能为空",3);
    }
    else{
        edit_info(user_id,"u_name",new_name);
    }
});

//关闭修改昵称隐藏的修改框
$(document).on('click','#edit-name>.head-box>.return', function(){
    if(open_edit_name == 1){
        window.history.back();
    }
});

//打开修改密码隐藏的修改框
$(document).on('click','.minepannel>.sets-box>.card>#open-edit-password', function(){
    historypush("#edit-password");
    open_edit_password = 1;
    $("#edit-password").fadeIn(300);
    $("#mine-safe>.shade").fadeIn(300);
});

//密码修改提交
$(document).on('click','#sub_user_pwd', function(){
    var pwd1 = $("#edit_user_pwd_1").val();
    var mediumRegex = new RegExp("^(?=.{7,})(((?=.*[A-Z])(?=.*[a-z]))|((?=.*[A-Z])(?=.*[0-9]))|((?=.*[a-z])(?=.*[0-9]))).*$", "g"); 
    if(!mediumRegex.test(pwd1)){
        add_msg("密码不能设置的太简单",3);
    }
    else{
        var pwd2 = $("#edit_user_pwd_2").val();
        if(pwd1 != pwd2){
            add_msg("两次密码输入不一样",3);
        }
        else{
            if(pwd1 == user_info.u_pwd){
                add_msg("密码与原密码一样",3);
                return 0;
            }
            edit_info(user_id,"u_pwd",pwd2);
        }
    }
});

//关闭修改密码隐藏的修改框
$(document).on('click','#edit-password>.head-box>.return', function(){
    if(open_edit_password == 1){
        window.history.back();
    }
});

//打开修改邮箱绑定隐藏的修改框
$(document).on('click','.minepannel>.sets-box>.card>#open-edit-email', function(){
    historypush("#edit-email");
    open_edit_email = 1;
    $("#edit-email").fadeIn(300);
    $("#mine-safe>.shade").fadeIn(300);
});

//关闭修改邮箱绑定隐藏的修改框
$(document).on('click','#sub_user_email', function(){
    if($.cookie("ecode")){
        var code = $.cookie("ecode");
        var code_check = md5($("#edit-email-code").val()).toLowerCase();
        if(code != code_check){
            add_msg("验证码错误!",3);
            $("#edit-email-code").val("");
        }
        else{
            var email = $.cookie("edit_email");
            $.cookie("ecode", "", {path: '/', expires: 0});
            $.cookie("edit_email", "", {path: '/', expires: 0});
            edit_info(user_id,"u_email",email);
        }
    }
    else{
        add_msg("验证码失效或未获取",3);
    }
});


//关闭修改邮箱绑定隐藏的修改框
$(document).on('click','#edit-email>.head-box>.return', function(){
    if(open_edit_email == 1){
        window.history.back();
    }
});

//打开修改手机绑定隐藏的修改框
$(document).on('click','.minepannel>.sets-box>.card>#open-edit-phone', function(){
    historypush("#edit-phone");
    open_edit_phone = 1;
    $("#edit-phone").fadeIn(300);
    $("#mine-safe>.shade").fadeIn(300);
});

//关闭修改手机绑定隐藏的修改框
$(document).on('click','#edit-phone>.head-box>.return', function(){
    if(open_edit_phone == 1){
        window.history.back();
    }
});

//提交修改手机号码
$(document).on('click','#sub_user_phone', function(){
    if($.cookie("pcode")){
        var code = $.cookie("pcode");
        var code_check = md5($("#edit-phone-code").val()).toLowerCase();
        if(code != code_check){
            add_msg("验证码错误!",3);
            $("#edit-phone-code").val("");
        }
        else{
            var phone = $.cookie("edit_phone");
            $.cookie("pcode", "", {path: '/', expires: 0});
            $.cookie("edit_phone", "", {path: '/', expires: 0});
            edit_info(user_id,"u_phone",phone);
        }
    }
    else{
        add_msg("验证码失效或未获取",3);
    }
});

//获取手机绑定中的手机验证码
$(document).on('click','#edit-phone-get', function(){
    var phonenumber = $("#edit-phone-set").val();
    if(!(/^1[3|4|5|7|8]\d{9}$/.test(phonenumber))){ 
        add_msg("手机号格式有误！",3);
        return 0;
    }
    if(phonenumber == user_info.u_phone){
        add_msg("手机号与原来一样",3);
        return 0;
    }
    if(!$(this).hasClass("disabled")){
        var haoyemao_pcodes = new haoyemao_pcode();
        haoyemao_pcodes.create(phonenumber);
        var msg = haoyemao_pcodes.getmsg();
        var pcode = haoyemao_pcodes.getcode();
        switch(msg)
        {
            case 0:
                add_msg("发送失败",3);
                break;
            case 1:
                add_msg("发送成功",1);
                var ttl = parseInt(300);				//验证码有效时长;
                var count = parseInt(60);				//邮箱验证码冷却时长;
                $.cookie("pcode", pcode, {path: '/', expires: (1 / 86400) * ttl * 10});
                $.cookie("edit_phone", phonenumber, {path: '/', expires: (1 / 86400) * ttl * 10});
                var timeout = Date.now() + count * 1000;//剩余过期时间
			    $.cookie("edit-phone-get", timeout, {path: '/', expires: (1 / 86400) * count});
			    time_cookie_exist("edit-phone-get", "#edit-phone-get", "#edit-phone-get>span");
                break;
            case -1:
                add_msg("手机号码不正确",3);
                break;
            case -2:
                add_msg("签名不正确",3);
                break;
            case -3:
                add_msg("发送频繁",3);
                break;
            default:
                add_msg("未知异常！",3);
                break;
        }
    }
});

//获取邮箱绑定中的邮箱验证码
$(document).on('click','#edit-email-get', function(){
    var email = $("#edit-email-set").val();
    if(!(/^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/.test(email))){ 
        add_msg("邮箱格式有误！",3);
        return 0;
    }
    if(email == user_info.u_email){
        add_msg("邮箱与原来一样",3);
        return 0;
    }
    if(!$(this).hasClass("disabled")){
        $("#loading_page").fadeIn(200);
        var haoyemao_ecodes = new haoyemao_ecode();
        haoyemao_ecodes.create(email);
        setTimeout(function() {
            var msg = haoyemao_ecodes.getmsg();
            var ecode = haoyemao_ecodes.getcode();
            $("#loading_page").fadeOut(200);
            switch(msg)
            {
                case 0:
                    add_msg("发送失败",3);
                    break;
                case 1:
                    add_msg("发送成功",1);
                    var ttl = parseInt(300);				//验证码有效时长;
                    var count = parseInt(60);				//邮箱验证码冷却时长;
                    $.cookie("ecode", ecode, {path: '/', expires: (1 / 86400) * ttl * 10});
                    $.cookie("edit_email", email, {path: '/', expires: (1 / 86400) * ttl * 10});
                    var timeout = Date.now() + count * 1000;//剩余过期时间
    			    $.cookie("edit-email-get", timeout, {path: '/', expires: (1 / 86400) * count});
    			    time_cookie_exist("edit-email-get", "#edit-email-get", "#edit-email-get>span");
                    break;
                case -1:
                    add_msg("邮箱格式有误！",3);
                    break;
                case -2:
                    add_msg("接口签名错误！",3);
                    break;
                case -100:
                    add_msg("接口调用次数不足！",3);
                    break;
                default:
                    add_msg("未知异常！",3);
                    break;
            }
        }, 400); 
    }
});

//邮箱绑定中输入框清空
$(document).on('click','#edit-email>.input>.clear-btn', function(){
    $("#edit-email-set").val("").focus();
});

//提交修改头像
$(document).on('click','#edit-avatar-sub', function(){
    if(edit_avataring == 1){
        return 0;
    }
    var container=document.getElementById('avatar-img');
  	//如果单位是rem：html2canvas(container,{width:w,height:h})
  	$("#loading_page").fadeIn(200);
	html2canvas(container).then(function(canvas) {
		var imgsrc = canvas.toDataURL("image/jpeg", 1);
		edit_avataring = 1;
        // var img = $("#avatar-img").attr("src");
        edit_info(user_id,"u_avatar",imgsrc);
	});
});

/* record */
//返回到上一页
$(document).on('click','#record-box>.head>.return-box', function(){
    window.history.back();
});

/* thingadd */
//返回键事件
$(document).on('click','#thingadd-box>.head>.return-box', function(){
    if(thingadd_box_open == 1 || thing_edit_open == 1 || search_edit_open == 1){
        window.history.back();
    }
});

//修复点击右侧箭头无反应
$(document).on('click','#thingadd-box>.add-box>.card>.contain>.itemline>.lq-xiangyou1',function(){
    $(this).parent().children("input").click();
});

//点击备注清空
$(document).on('click','#addthing_beizhu',function(){
    if($(this).text() == "请输入备注信息(100字以内)"){
        $(this).text("");
    }
});

//备注内容监听
$(document).on("input propertychange",'#addthing_beizhu',function() {
    $("#addthing_beizhu").val($("#addthing_beizhu").val().replace(/[\r\n]/g,""));//取消换行
    var $this = $(this),
        _val = $this.val(),
        count = $this.val().length;
    $("#addthing_beizhu_len").text(count + "/1000");
    if(count >= 1000){
        $("#addthing_beizhu_len").addClass("type-danger").removeClass("type-disable");
    }
    else{
        $("#addthing_beizhu_len").addClass("type-disable").removeClass("type-danger");
    }
});

//取消返回事件
$(document).on('click','#thingadd-box>.add-box>.btn-box>.cancel',function(){
    window.history.back();
});

/* thinglist */

//修复点击小图标没相应的问题
$(document).on('click','#thinglist-box>.check-box>.item>.click', function(){
    $(this).parent().children(".value").click();
});

$(document).on('click','#thinglist-box>.head>.return-box', function(){
    if(thinglist_batch_del_box_open == 1){
        window.history.back();
    }
    window.history.back();
});

//点击批量删除
$(document).on('click','#thinglist-box>.statetag-box>.multidel', function(){
    if(loading_page == 1)return 0;
    if(thinglist_batch_del_box_open == 0 && thing_edit_open == 0){
        $("#thinglist-box>.bacth").css("transform","translateY(-100%)");
        $("#thinglist-box>.list-box").css("height","calc(100% - 190px)");
        $("#thinglist-box>.list-box>.card-box>.card").css("margin-left","calc(50% - 130px)");
        $("#thinglist-box>.list-box>.card-box>.batch-box").fadeIn(300);
        $("#thinglist-box>.list-box>.card-box>.batch-box").css("transform","translateX(0px)");
        $("#thinglist-box>.list-box>.card-box>.card>.body>.btnbox").fadeOut(300);
        thinglist_batch_del_box_open = 1;
        delthings = [];
        historypush("thinglist_batch_del_box");
        $("#thinglist-box>.list-box>.card-box>.batch-box>input").prop("checked", false);//有bug 
    }
});
// 取消批量删除
$(document).on('click','#thinglist-box>.bacth>.cancel', function(){
    window.history.back();
});

//批量删除选择
$(document).on('change','#thinglist-box>.list-box>.card-box>.batch-box>input', function(){
    // if($(this).is(":checked")){
    //     // 此时选中
    //     $(this).parent().parent().children(".card").css("filter","grayscale(1)");
    //     $(this).parent().parent().children(".card").css("opacity","0.5");
    // }
    // else{
    //     // 此时取消选中
    //     $(this).parent().parent().children(".card").css("filter","grayscale(0)");
    //     $(this).parent().parent().children(".card").css("opacity","1");
    // }
    var obj = $(this);
    var that = $(this).parent().parent().children(".card");
    if(obj.is(":checked")){
        that.css("filter","grayscale(1)");
        that.css("opacity","0.5");
        var id = that.parent().attr("id");
        delthings.push(id);
    }
    else{
        that.css("filter","grayscale(0)");
        that.css("opacity","1");
        var id = that.parent().attr("id");
        var k;
        k = -1;
        for(var i = 0; i < delthings.length; i++){
            if(delthings[i] == id){
                k = i;
                break;
            }
        }
        if(k != -1){
           delthings.splice( k ,1); 
        }
    }
});

//点击card的事件
$(document).on('click','#thinglist-box>.list-box>.card-box>.card', function(){
    if(thinglist_batch_del_box_open == 1){//批量删除打开的状态
        var obj = $(this).parent().children(".batch-box").children("input");
        if(!obj.is(":checked")){
            var id = $(this).parent().attr("id");
            $(this).css("filter","grayscale(1)");
            $(this).css("opacity","0.5");
            obj.prop("checked", true);
            delthings.push(id);
        }
        else{
            $(this).css("filter","grayscale(0)");
            $(this).css("opacity","1");
            obj.prop("checked", false);
            var id = $(this).parent().attr("id");
            var k;
            k = -1;
            for(var i = 0; i < delthings.length; i++){
                if(delthings[i] == id){
                    k = i;
                    break;
                }
            }
            if(k != -1){
               delthings.splice( k ,1); 
            }
            //标记1
        }
    }
    else{
		//打开细节隐藏框
        if(thing_detail_box_open == 0 && thing_edit_open == 0){
            $("#loading_page").fadeIn(300);
            var id = $(this).parent().attr("id").split("_");
            setTimeout(function() {set_detail_card(id[1] - 1); }, 400);
            $("#detail-box").fadeIn(200);
            $("#detail-shade").fadeIn(200);
            thing_detail_box_open = 1;
            historypush("thing_detail_box_open");
        }
    }
});

// 关闭隐藏物品具体信息框
$(document).on('click','#detail-box>.head>.closebtn', function(){
    window.history.back();
});

//编辑按钮
$(document).on('click','#thinglist-box>.list-box>.card-box>.card>.body>.btnbox>.edit>.edit', function(e){
    e.stopPropagation();
    if(thinglist_batch_del_box_open != 1 && thing_edit_open == 0){
        setTimeout(function() {$("#loading_page").fadeIn(300); }, 300); 
        $("#thingadd-box>.add-box").css("opacity","1");
        $("#thingadd-box").css("transform","translateX(0%)");
        //开启返回获得
        $("#thingadd-box>.head>.title>span").html("物品编辑");
        $("#thingadd-box>.add-box>.btn-box>.btn.edit").css("display","block");
        $("#thingadd-box>.add-box>.btn-box>.btn.submit").css("display","none");
        thing_edit_open = 1;
        historypush("#thingadd-box>.head>.return-box");
        var t_id_t = $(this).parent().parent().parent().parent().parent().attr("id").split("_");
        var id = t_id_t[1] - 1;
        var t_id = t_id_t[2];
        thing_edit_id = t_id;
        if(get_thing_id(t_id) != id){
            add_msg("该物品不存在",3);
            return 0;
        }
        setTimeout(function() {addthing_set(id); }, 400);//设置信息
    }
});

//开启详情中的物品编辑
$(document).on('click','#thing_detail_edit', function(e){
    e.stopPropagation();
    setTimeout(function() {$("#loading_page").fadeIn(300); }, 300); 
    $("#thingadd-box>.add-box").css("opacity","1");
    $("#thingadd-box").css("transform","translateX(0%)");
    //开启返回获得
    $("#thingadd-box>.head>.title span").html("物品编辑");
    thing_detail_box_open_item = 1;
    thing_edit_open = 1;
    var id = $("#detail-box").attr('name');
    thing_edit_id = things[id].t_id;
    setTimeout(function() {addthing_set(id); }, 500); //设置信息
    $("#thingadd-box>.add-box>.btn-box>.btn.edit").css("display","block");
    $("#thingadd-box>.add-box>.btn-box>.btn.submit").css("display","none");
    
    historypush("#thingadd-box>.head>.return-box");
});

//标签选择事件
$(document).on('click','#thinglist-box>.head>.list_class', function(e){
    e.stopPropagation();
});

//打开物品记录
$(document).on('click','#thing_detail_record', function(){
    var id = things[$("#detail-box").attr('name')].t_id;
    if(thing_detail_record_open == 0){
        $("#record-box").css("transform","translateX(0%)");
        thing_detail_record_open = 1;
        thing_detail_box_open_item = 1;
        historypush("#record-box>.head>.return-box");
        record_list_get(id);
    }
});

//类型标签点击事件
$(document).on('click','#thinglist-box>.statetag-box>.tag', function(){
    if(thinglist_batch_del_box_open == 1){
        window.history.back();
    }
    if(loading_page == 1)return 0;
    if($(this).hasClass("disable")){
        $(this).removeClass("disable");
    }
    else{
        if(thing_type == 1 || thing_type == 2 || thing_type == 4)return 0;
        $(this).addClass("disable");
    }
    var tag1,tag2,tag3;
    tag1 = 1;
    tag2 = 2;
    tag3 = 4;
    if($("#thinglist_tag_1").hasClass("disable")){
        tag1 = 0;
    }
    if($("#thinglist_tag_2").hasClass("disable")){
        tag2 = 0;
    }
    if($("#thinglist_tag_3").hasClass("disable")){
        tag3 = 0;
    }
    thing_type = tag1 + tag2 + tag3;
    page = 0;
    list_clear_thing('#thinglist-box>.list-box','thinglist-loading-box');
    loading_page = 1;
    page_items = -1;
    loading_start("#thinglist-loading-box");
    get_thing(user_id,thing_type,thing_c_id,thing_name_key,thing_creat,sort_type,sort_method,++page);
});

/* thingsearch */
//返回主页
$(document).on('click','#thingsearch-box>.head>.return-box', function(){
    if(search_open == 1){
        window.history.back();
    }
    if(thing_detail_box_open == 1){
        window.history.back();
    }
    if(search_batch_del_box_open == 1){
        window.history.back();
    }
    window.history.back();
});

//关闭侧边栏
$(document).on('click','#search-item-box>.head>.return-box', function(){
    if(search_open == 1){
       window.history.back(); 
    }
});

//打开侧边栏
$(document).on('click','#thingsearch-box>.head>.open-searchbox', function(){
    if(search_batch_del_box_open == 1){
        window.history.back();
        return 0;
    }
    $("#loading_page").fadeIn(300);
    if(search_open == 0){
        $("#search-item-name").val(thing_name_key);
        var classset = get_class_id(thing_c_id);
        if(classset == -1){
            search_box_select.locatePosition(0,0);
            $("#search-box-select>.text").text("全部");
        }
        else{
            search_box_select.locatePosition(0,classset);
        }
        var tt = thing_type;
        if(tt >= 4){
            $("#searchlist_tag_1").removeClass("disable");
            tt = tt - 4;
        }
        else{
            $("#searchlist_tag_1").addClass("disable");
        }
        if(tt >= 2){
            $("#searchlist_tag_2").removeClass("disable");
            tt = tt - 2;
        }
        else{
            $("#searchlist_tag_2").addClass("disable");
        }
        if(tt >= 1){
            $("#searchlist_tag_3").removeClass("disable");
            tt = tt - 1;
        }
        else{
            $("#searchlist_tag_3").addClass("disable");
        }
        historypush("#search-item-box");
        $("#search-item-box").css("transform","translateX(0%)");
        $("#thingsearch-box>.shade").fadeIn(100);
        search_open = 1;
    }
    $("#loading_page").fadeOut(300);
});

//点击批量删除
$(document).on('click','#search-box>.statetag-box>.multidel', function(){
    if(loading_page == 1)return 0;
    if(search_batch_del_box_open == 0 && thing_edit_open == 0){
        $("#search-box>.bacth").css("transform","translateY(-100%)");
        $("#search-box>.list-box").css("height","calc(100% - 170px)");
        $("#search-box>.list-box>.card-box>.card").css("transform","translateX(20px)");
        $("#search-box>.list-box>.card-box>.batch-box").fadeIn(300);
        $("#search-box>.list-box>.card-box>.batch-box").css("transform","translateX(0px)");
        $("#search-box>.list-box>.card-box>.card>.body>.btnbox").fadeOut(300);
        search_batch_del_box_open = 1;
        delthings = [];
        historypush("search_batch_del_box");
        $("#search-box>.list-box>.card-box>.batch-box>input").prop("checked", false);
        $("#thingsearch-box>.head>.open-searchbox").hide();
    }
});

// 取消批量删除
$(document).on('click','#search-box>.bacth>.cancel', function(){
    window.history.back();
});

//批量删除选择
$(document).on('change','#search-box>.list-box>.card-box>.batch-box>input', function(){
    // if($(this).is(":checked")){
    //     // 此时选中
    //     $(this).parent().parent().children(".card").css("filter","grayscale(1)");
    //     $(this).parent().parent().children(".card").css("opacity","0.5");
    // }
    // else{
    //     // 此时取消选中
    //     $(this).parent().parent().children(".card").css("filter","grayscale(0)");
    //     $(this).parent().parent().children(".card").css("opacity","1");
    // }
    var obj = $(this);
    var that = $(this).parent().parent().children(".card");
    if(obj.is(":checked")){
        that.css("filter","grayscale(1)");
        that.css("opacity","0.5");
        var id = that.parent().attr("id");
        delthings.push(id);
    }
    else{
        that.css("filter","grayscale(0)");
        that.css("opacity","1");
        var id = that.parent().attr("id");
        var k;
        k = -1;
        for(var i = 0; i < delthings.length; i++){
            if(delthings[i] == id){
                k = i;
                break;
            }
        }
        if(k != -1){
           delthings.splice( k ,1); 
        }
    }
});

//点击card的事件
$(document).on('click','#search-box>.list-box>.card-box>.card', function(){
    if(search_batch_del_box_open == 1){//批量删除打开的状态
        var obj = $(this).parent().children(".batch-box").children("input");
        if(!obj.is(":checked")){
            $(this).css("filter","grayscale(1)");
            $(this).css("opacity","0.5");
            obj.prop("checked", true);
            var id = $(this).parent().attr("id");
            delthings.push(id);
        }
        else{
            $(this).css("filter","grayscale(0)");
            $(this).css("opacity","1");
            obj.prop("checked", false);
            var id = $(this).parent().attr("id");
            var k;
            k = -1;
            for(var i = 0; i < delthings.length; i++){
                if(delthings[i] == id){
                    k = i;
                    break;
                }
            }
            if(k != -1){
               delthings.splice( k ,1); 
            }
        }
    }
    else{//打开细节隐藏框
        if(thing_detail_box_open == 0 && thing_edit_open == 0)
        {
            $("#loading_page").fadeIn(300);
            var id = $(this).parent().attr("id").split("_");
            setTimeout(function() {set_detail_card(id[1] - 1); }, 300); 
            $("#detail-box").fadeIn(200);
            $("#detail-shade").fadeIn(200);
            thing_detail_box_open = 1;
            historypush("thing_detail_box_open");
        }
    }
});

//编辑按钮
$(document).on('click','#search-box>.list-box>.card-box>.card>.body>.btnbox>.edit>.edit', function(e){
    e.stopPropagation();
    if(search_batch_del_box_open != 1 && thing_edit_open == 0){
        setTimeout(function() {$("#loading_page").fadeIn(300); }, 300); 
        $("#thingadd-box>.add-box").css("opacity","1");
        $("#thingadd-box").css("transform","translateX(0%)");
        //开启返回获得
        $("#thingadd-box>.head>.title>span").html("物品编辑");
        $("#thingadd-box>.add-box>.btn-box>.btn.edit").css("display","block");
        $("#thingadd-box>.add-box>.btn-box>.btn.submit").css("display","none");
        thing_edit_open = 1;
        historypush("#thingadd-box>.head>.return-box");
        var t_id_t = $(this).parent().parent().parent().parent().parent().attr("id").split("_");
        var id = t_id_t[1] - 1;
        var t_id = t_id_t[2];
        thing_edit_id = t_id;
        if(get_thing_id(t_id) != id){
            add_msg("该物品不存在",3);
            return 0;
        }
        setTimeout(function() {addthing_set(id); }, 400); //设置信息
    }
});

//物品分类获取
$(document).on('click','#search-box-select', function(){
    search_box_select_open = 1;
});

//关闭询问框（叉方法）
$(document).on('click','.require-box>.head-box>.cancel', function(){
    if(require_box_open == 1){
        window.history.back();
    }
});

//询问框确定事件
$(document).on('click','.require-box>.btn-box>.sure', function(){
    var act = $(this).attr("id").split("_");
    if(act[0] == "delc"){
        del_class(act[1]);
        window.history.back();
    }
    else if(act[0] == "delt"){
        if(require_box_open == 1){
            window.history.back();
        }
        if(thing_detail_box_open == 1){
            window.history.back();
        }
        del_thing("_");
    }
    else if(act[0] == "pro"){
        var t_change = $("#t-num-pro").val();
        if(t_change == "0" || t_change == ""){
            add_msg("处理数量不能为0",3);
            return 0;
        }
        if($(".t-num-increase").hasClass("t-num-dark")){
            t_change = -t_change;
        }
        pro_thing(act[1],t_change);
    }
    else if(act[0] == "exit"){
        $.cookie("seven_login_id","",{path: '/',expires: -1});
        $.cookie("login_in","",{path: '/',expires: -1});
        window.history.back();
        add_msg("成功退出");
        setTimeout(function() {window.location.replace("../login.php"); }, 300);//设置信息
    }
    else if(act[0] == "deltm"){
        window.history.back();
        del_thing("_");
    }
});

//关闭询问框（取消方法）
$(document).on('click','.require-box>.btn-box>.cancel', function(){
    if(require_box_open == 1){
        window.history.back();
    }
});

//添加物品
$(document).on('click','#sub_addthing', function(){
    var name = htmlEncodeJQ($("#addthing_name").val());
    var num = parseInt($("#addthing_num").val());
    var c_id_t = $("#addthing_boxclass").val();
    var c_id;
    if(c_id_t == ""){
        c_id = -1;
    }
    else{
       c_id = classes[get_class_name(c_id_t)].c_id;
    }
    var time_p = $("#addthing_produce_date").val();
    var time_o = $("#addthing_overdue_date").val();
    var time_a = $("#addthing_near_days").val();
    var beizhu = htmlEncodeJQ($("#addthing_beizhu").val());
    if(name == ""){
        add_msg("名称不能为空",2);
        return 0;
    }
    if(num == ""){
        add_msg("数量不能为空",2);
        return 0;
    }
    if(num < 0){
        add_msg("数量不能为负数",2);
        return 0;
    }
    if(c_id == -1){
        add_msg("分类不能为空",2);
        return 0;
    }
    if(time_p == ""){
        add_msg("生产日期不能为空",2);
        return 0;
    }
    if(time_o == ""){
        add_msg("到期日期不能为空",2);
        return 0;
    }
    if(time_a == ""){
        add_msg("临期时间不能为空",2);
        return 0;
    }
    if(thing_detail_box_open_item != 1){
        $("#loading_page").fadeIn(300);
        add_thing(user_id, name, num, c_id, time_p, time_o, time_a, beizhu);
    }
});

//添加物品
$(document).on('click','#sub_editthing', function(){
    var name = htmlEncodeJQ($("#addthing_name").val());
    var num = parseInt($("#addthing_num").val());
    var c_id_t = $("#addthing_boxclass").val();
    var c_id;
    if(c_id_t == ""){
        c_id = -1;
    }
    else{
       c_id = classes[get_class_name(c_id_t)].c_id;
    }
    var time_p = $("#addthing_produce_date").val();
    var time_o = $("#addthing_overdue_date").val();
    var time_a = $("#addthing_near_days").val();
    var beizhu = htmlEncodeJQ($("#addthing_beizhu").val());
    if(name == ""){
        add_msg("名称不能为空",2);
        return 0;
    }
    if(num == ""){
        add_msg("数量不能为空",2);
        return 0;
    }
    if(num < 0){
        add_msg("数量不能为负数",2);
        return 0;
    }
    if(c_id == -1){
        add_msg("分类不能为空",2);
        return 0;
    }
    if(time_p == ""){
        add_msg("生产日期不能为空",2);
        return 0;
    }
    if(time_o == ""){
        add_msg("到期日期不能为空",2);
        return 0;
    }
    if(time_a == ""){
        add_msg("临期时间不能为空",2);
        return 0;
    }
    edit_thing(thing_edit_id, name, num, c_id, time_p, time_o, time_a, beizhu);
});


//修复ios端输入问题
$(document).on("compositionstart","#addthing_name",function(){
    flag = false;
})
$(document).on("compositionend","#addthing_name",function(){
    flag = true;
})
        


//物品名称监听
$(document).on("input propertychange",'#addthing_name',function() {
    if(!flag)return;
    $("#addthing_name").val($("#addthing_name").val().replace(/[\r\n]/g,""));//取消换行
    var $this = $(this),
        _val = $this.val(),
        count = $this.val().length;
    if(count == 50){
        add_msg("最长只可50个字符",2);
    }
});

//物品数量监听
$(document).on("input propertychange",'#addthing_num',function() {
    $("#addthing_num").val(parseInt($("#addthing_num").val()).toString());//取消换行
    var $this = $(this),
        _val;
    if($this.val() == ""){
        _val = 0;
    }
    else{
        _val = parseInt($this.val());
    }
    if(_val > 1000000){
        add_msg("最多不可超过1000000",2);
        $this.val("1000000");
    }
});

//物品到期天数监听
$(document).on("input propertychange",'#addthing_overdue_date_num',function() {
    $("#addthing_overdue_date_num").val($("#addthing_overdue_date_num").val().replace(/[\r\n\.\+\-]/g,""));//取消换行
    var $this = $(this),
        _val;
    if($this.val() == ""){
        _val = 0;
    }
    else{
        _val = parseInt($this.val());
    }
    var tdate = $("#addthing_produce_date").val();  //生产日期
    if(tdate == ""){
        add_msg("未设置生产日期，已设为默认值",2);
        $("#addthing_produce_date").val(y_m_d_now);
        produce_date.locatePosition(0,year_now - 1999);
        produce_date.locatePosition(1,month_now);
        produce_date.locatePosition(2,day_now - 1);
        tdate = y_m_d_now;
    }
    var tdate2 = AddDays(tdate, _val);              //到期日期
    if(tdate2 > "2099-12-31"){
        add_msg("超过最大值",2);
        tdate2 = "2099-12-31";
        var _t = getDaysBetween(tdate,tdate2);
        $('#addthing_overdue_date_num').val(_t);
    }
    var t = tdate2.split('-');
    overdue_date.locatePosition(0,parseInt(t[0]) - 1999);
    overdue_date.locatePosition(1,parseInt(t[1]) - 1);
    overdue_date.locatePosition(2,parseInt(t[2]) - 1);
    $('#addthing_overdue_date').val(tdate2);
    
    //临期不合理
    if($("#addthing_near_days").val() == ""){
        return 0;
    }
    tdate3 = $("#addthing_near_date").val();
    var ttnum = getDaysBetween(y_m_d_now,tdate2);
    if(tdate3 < tdate || tdate2 < tdate3 || tdate3 < y_m_d_now){
        add_msg("临期不合理",2);
        if(ttnum > 7){
            ttnum = 7;
        }
        else if(ttnum > 3){
            ttnum = 3;
        }
        else{
            ttnum = 0;
        }
        tdate3 = AddDays(tdate2, -ttnum);
    }
    else{
        return 0;
    }
    t = tdate3.split('-');
    near_date.locatePosition(0,t[0] - 1999);
    near_date.locatePosition(1,t[1]-1);
    near_date.locatePosition(2,t[2] - 1);
    $('#addthing_near_date').val(tdate3);
    $('#addthing_near_days').val(ttnum);
});

//临期天数监听
$(document).on("input propertychange",'#addthing_near_days',function() {
    $("#addthing_near_days").val($("#addthing_near_days").val().replace(/[\r\n\.\+\-]/g,""));//取消换行
    var $this = $(this),
        _val;
    if($this.val() == ""){
        _val = 0;
    }
    else{
        _val = parseInt($this.val());
    }
    var tdate = $("#addthing_produce_date").val();  //生产日期
    var tdate2 = $("#addthing_overdue_date").val(); //到期日期
    if(tdate2 == ""){
        add_msg("请先设置到期时间！",2);
        $this.val("");
        return 0;
    }
    var ttnum = getDaysBetween(y_m_d_now,tdate2);
    if(_val > ttnum){
        add_msg("临期不合理",2);
        if(ttnum > 7){
            ttnum = 7;
        }
        else if(ttnum > 3){
            ttnum = 3;
        }
        else{
            ttnum = 0;
        }
    }
    else{
        ttnum = _val;
    }
    tdate3 = AddDays(tdate2, -ttnum);
    var t = tdate3.split('-');
    near_date.locatePosition(0,t[0] - 1999);
    near_date.locatePosition(1,t[1]-1);
    near_date.locatePosition(2,t[2] - 1);
    $('#addthing_near_date').val(tdate3);
    $('#addthing_near_days').val(ttnum);
});

//thinglist批量删除
$(document).on("click",'#thinglist-box>.bacth>.del',function(){
    var del_t_id="";
    if(delthings.length <= 0){
        add_msg("未选中任何物品",2);
        return 0;
    }
    add_require("确定删除吗?", "删除后没有办法恢复嗷~", "确定", "取消", "deltm", "", "#thinglist-box");
});

//thinglist-card删除
$(document).on("click",'#thinglist-box>.list-box>.card-box>.card>.body>.btnbox>.del>.del',function(e){
    delthings = [];
    e.stopPropagation();
    var id;
    var code = "删除后没有办法恢复嗷~";
    id = $(this).parent().parent().parent().parent().parent().attr("id");
    delthings.push(id);
    add_require("确定删除吗?", code, "确定", "取消", "delt_" + id, "", "#thinglist-box");
});

//thinglist批量删除
$(document).on("click",'#search-box>.bacth>.del',function(){
    if(delthings.length <= 0){
        add_msg("未选中任何物品",2);
        return 0;
    }
    add_require("确定删除吗?", "删除后没有办法恢复嗷~", "确定", "取消", "deltm", "", "#search-box");
});

//thinglist-card删除
$(document).on("click",'#search-box>.list-box>.card-box>.card>.body>.btnbox>.del>.del',function(e){
    delthings = [];
    e.stopPropagation();
    var id;
    var code = "删除后没有办法恢复嗷~";
    id = $(this).parent().parent().parent().parent().parent().attr("id");
    delthings.push(id);
    add_require("确定删除吗?", code, "确定", "取消", "delt_" + id, "", "#search-box");
});

//详情卡片删除
$(document).on("click","#thing_detail_delete",function(e){
    delthings = [];
    e.stopPropagation();
    var id;
    var code = "删除后没有办法恢复嗷~";
    id = parseInt($(this).parent().parent().parent().attr("name"));
    tid = "t_" + (id + 1).toString() + "_" + things[id].t_id;
    delthings.push(tid);
    add_require("确定删除吗?", code, "确定", "取消", "delt_" + tid, "", "#detail-box");
});

//详情卡片处理
$(document).on("click","#thing_detail_operator",function(e){
    delthings = [];
    e.stopPropagation();
    var id;
    var code = "<div class='t-num-reduce'>消耗</div>\
                <div class='t-num-increase t-num-dark'>补充</div>\
                <input id='t-num-pro' type='number' placeholder='请输入数量'/>\
                ";
    id = parseInt($(this).parent().parent().parent().attr("name"));
    tid = things[id].t_id;
    add_require("物品处理！", code, "确定", "取消", "pro_" + tid, "", "#detail-box");
});

//物品处理监听
$(document).on("input propertychange",'#t-num-pro',function() {
    $("#t-num-pro").val(parseInt($("#t-num-pro").val()).toString());//取消换行
    var $this = $(this),
        _val;
    if($this.val() == ""){
        _val = 0;
    }
    else{
        _val = parseInt($this.val());
    }
    if(_val > 1000000){
        add_msg("最多不可超过1000000",2);
        $this.val("1000000");
    }
});

//物品处理选择
$(document).on("click",'.t-num-increase',function() {
    if($(this).hasClass("t-num-dark")){
        $(this).removeClass("t-num-dark");
        $('.t-num-reduce').addClass("t-num-dark");
    }
});
$(document).on("click",'.t-num-reduce',function() {
    if($(this).hasClass("t-num-dark")){
        $(this).removeClass("t-num-dark");
        $('.t-num-increase').addClass("t-num-dark");
    }
});

//点击反馈问题跳转
$(document).on("click",'#feedback_qq',function() {
    window.location.href="https://qm.qq.com/cgi-bin/qm/qr?k=6yrvKFjIiBvBiH8U46qtfrAbWxicAgrx&jump_from=webapi";
});

//标题栏点击跳转
$(document).on("click",'#turnto_mine',function() {
    $("#to_mine").click();
    $("#menu-avatar").click();
});

//退出登录2
$(document).on("click",'#exit',function() {
    add_require("退出提示", "确定退出登录吗？", "确定", "取消", "exit", "", "body");
    $("#menu-avatar").click();
});

//说明
$(document).on("click",'#open-instruction',function() {
    add_msg("程序员还在火速编写ing~");
});

//协议
$(document).on("click",'#open-protocol',function() {
    add_msg("程序员还在火速编写ing~");
});