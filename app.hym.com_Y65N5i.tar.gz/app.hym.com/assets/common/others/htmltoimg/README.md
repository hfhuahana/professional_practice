# html_to_image
详细使用请前往我的博客[html页面转换成图片的三种方法——canvas、dom-to-image、html2canvas](https://blog.csdn.net/weixin_38233549/article/details/97940750)查看。
