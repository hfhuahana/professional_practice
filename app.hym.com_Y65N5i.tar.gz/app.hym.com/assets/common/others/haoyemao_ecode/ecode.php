<html>
<head>
    <meta charset="utf-8">
    <script type="text/javascript" src="./haoyemao-ecode.js?v=2"></script>
    <title>好耶猫API</title>
    <style>
        #e-code
        {
            height:40px;
            line-height:38px;
            max-width:100%;
            margin-left:5%;
            background-color:rgba(191, 120, 58,0.3);
            border-radius:7px;
            color:#fff;
            border-color:rgba(167, 56, 54,1);
            border-style:solid;
            box-sizing:border-box;
            border-width:2px;
            font-size:12px;
            outline:none;
            text-align:center;
        }
    </style>
</head>
<body>
    <div class="form-item">
        <div style="float:left;height:40px;width:30%;">
            <div id="e-code">获取验证码</div>
        </div>
    </div>
    <script>
    //邮箱验证码发送
    $(function(){
        $('#e-code').click(function()
        {
            var email = "773867006@qq.com";
            //支持创建对象数组
            haoyemao_ecodes = new haoyemao_ecode();
            haoyemao_ecodes.create(email);
            
            alert(haoyemao_ecodes.getcode());//获取验证码的md5
            alert(haoyemao_ecodes.getmsg());//获取验证码错误信息
        });
    });
    </script>
</body>
</html>