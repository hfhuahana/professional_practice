<?php
/**
 * 发送post请求
 * @param string $url 请求地址
 * @param array $post_data post键值对数据
 * @return string
 */
function send_post($url, $post_data) {
    $postdata = http_build_query($post_data);
    $options = array(
        'http' => array(
            'method' => 'POST',
            'header' => 'Content-type:application/x-www-form-urlencoded',
            'content' => $postdata,
            'timeout' => 15 * 60 // 超时时间（单位:s）
        )
    );
    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
    return $result;
}
function send_get($url, $get_data){
    $query = http_build_query($get_data);
    $result = file_get_contents($url.'?'.$query);
    return $result;
}

//签名生成
function signature_creat($id,$pwd,$func){
    $text = $id."|".$pwd."|".$func;
    return md5($text);
}
//参数配置
$id = 1;//api的id
$pwd = "baorenjun";//api的密码
$len = 4;//验证码长度
$title = "好耶猫API登录验证码";//邮件标题
$name = "好耶猫API";//发送者昵称
//获取参数
if(isset($_POST['to'])){
    $data = array(
        'id' => $id,
        'pwd' => $pwd,
        'func' => "ecode",       //接口名
        'len' => $len,
        'to' => $_POST['to'],
        'title' => $title,
        'name' => $name, //标准值
        'sign' => signature_creat($id,$pwd,"ecode"),//签名
        'time' => time()
    );
    $api_url = "http://api.haoyemao.com/api.php";//接口地址
    echo send_get($api_url,$data);
}
else{
    echo "非法调用！";
}
?>