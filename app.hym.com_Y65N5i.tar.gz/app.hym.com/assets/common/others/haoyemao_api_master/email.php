<html>
<head>
    <meta charset="utf-8">
    <script type="text/javascript" src="./haoyemao-api.js"></script>
    <title>好耶猫API</title>
    <style>
        #e-send
        {
            height:40px;
            line-height:38px;
            max-width:100%;
            margin-left:5%;
            background-color:rgba(191, 120, 58,0.3);
            border-radius:7px;
            color:#fff;
            border-color:rgba(167, 56, 54,1);
            border-style:solid;
            box-sizing:border-box;
            border-width:2px;
            font-size:12px;
            outline:none;
            text-align:center;
        }
    </style>
</head>
<body>
    <div class="form-item">
        <div style="float:left;height:40px;width:30%;">
            <div id="e-send">发送邮件</div>
        </div>
    </div>
    <script>
    //邮箱验证码发送
    $(function(){
        $('#e-send').click(function()
        {
            var email = "@qq.com";
            var title = "好耶猫测试标题";
            var name = "好耶猫测试者";
            var msg = "好耶猫测试内容";
            //支持创建对象数组
            haoyemao_emails = new haoyemao_email();
            haoyemao_emails.create(email,title,name,msg);
            
            alert(haoyemao_emails.getto());//获取邮件发送者
            alert(haoyemao_emails.getmsg());//获取邮件错误信息
        });
    });
    </script>
</body>
</html>