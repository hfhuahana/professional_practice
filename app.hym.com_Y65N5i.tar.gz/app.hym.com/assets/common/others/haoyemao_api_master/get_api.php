<?php
/**
 * 发送post请求
 * @param string $url 请求地址
 * @param array $post_data post键值对数据
 * @return string
 */
function send_post($url, $post_data) {
    $postdata = http_build_query($post_data);
    $options = array(
        'http' => array(
            'method' => 'POST',
            'header' => 'Content-type:application/x-www-form-urlencoded',
            'content' => $postdata,
            'timeout' => 15 * 60 // 超时时间（单位:s）
        )
    );
    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
    return $result;
}

function send_get($url, $get_data){
    $query = http_build_query($get_data);
    $result = file_get_contents($url.'?'.$query);
    return $result;
}

//签名生成
function signature_creat($id,$pwd,$func){
    $text = $id."|".$pwd."|".$func;
    return md5($text);
}
//参数配置
$id = 1;//api的id
$pwd = "baorenjun";//api的密码
$func = isset($_POST['func'])? $_POST['func']: "";//接口类型选择

$send = 1;
switch($func)
{
    case "code":
        $len = 4;//普通验证码长度
        $data = array(
            'id' => $id,
            'pwd' => $pwd,
            'v' => rand(0,99999),   //防碰撞值
            'func' => "code",       //接口名
            'len' => $len,
            'index' => $_POST['index'], //标准值
            'sign' => signature_creat($id,$pwd,"code"),//签名
            'time' => time()
        );
        break;
    case "ecode":
        $len = 4;//验证码长度
        $title = "好耶猫验证码";//邮件标题
        $name = "好耶猫";//发送者昵称
        $data = array(
            'id' => $id,
            'pwd' => $pwd,
            'func' => "ecode",       //接口名
            'len' => $len,
            'to' => $_POST['to'],
            'title' => $title,
            'name' => $name, //标准值
            'sign' => signature_creat($id,$pwd,"ecode"),//签名
            'time' => time()
        );
        break;
    case "email":
        if(isset($_POST['to']) && isset($_POST['title']) && isset($_POST['name']) && isset($_POST['v'])){
            $data = array(
                'id' => $id,
                'pwd' => $pwd,
                'func' => "email",       //接口名
                'to' => $_POST['to'],
                'title' => $_POST['title'],
                'name' => $_POST['name'],
                'v' => $_POST['v'],
                'sign' => signature_creat($id,$pwd,"email"),//签名
                'time' => time()
            );
        }
        else{
            echo "非法调用！";
            $send = 0;
        }
        break;
    case "pcode":
        $len = 4;//验证码长度
        if(isset($_POST['to'])){
            $data = array(
                'id' => $id,
                'pwd' => $pwd,
                'func' => "pcode",       //接口名
                'len' => $len,
                'to' => $_POST['to'],
                'sign' => signature_creat($id,$pwd,"pcode"),//签名
                'time' => time(),
                'template' => 1323509
            );
        }
        else{
            echo "非法调用！";
            $send = 0;
        }
        break;
    default:
        echo "非法调用！";
        $send = 0;
        break;
}
//获取参数

$api_url = "http://api.haoyemao.com/api.php";//接口地址
if($send){
    echo send_get($api_url,$data);
}
?>