<div class="pannel-body" id="pannel-mine">
    <div class="about-mine">
        <div class="avatar-box">
            <img class="avatar" id="user_info_avatar" src="../public/avatar/avatar.jpg"/>
        </div>
        <div class="info-box">
            <div class="name">
                <span id="user_info_name">好耶猫</span>
            </div>
            <div class="id">
                <span>ID：</span>
                <span id="user_info_id">123</span>
            </div>
        </div>
        <div class="btn-box">
            <div class="btn" id="edit-self">
                <span class="hymicon lq-xiangyoujiantou"></span>
            </div>
        </div>
    </div>
    <div class="sets-item-box">
        <div class="card">
            <div class="item-box" id="mine-safe-open">
                <div class="icon-box">
                    <span class="hymicon lq-anquan"></span>
                </div>
                <div class="label-box">
                    <span>账号&安全</span>
                </div>
                <div class="icon-box">
                    <span class="hymicon lq-xiangyoujiantou"></span>
                </div>
            </div>
            <hr>
            <div class="item-box" id="mine-help-open">
                <div class="icon-box">
                    <span class="hymicon lq-bangzhu1"></span>
                </div>
                <div class="label-box">
                    <span>帮助文档</span>
                </div>
                <div class="icon-box">
                    <span class="hymicon lq-xiangyoujiantou"></span>
                </div>
            </div>
            <hr>
            <div class="item-box" id="mine-set-open">
                <div class="icon-box">
                    <span class="hymicon lq-shezhi3"></span>
                </div>
                <div class="label-box">
                    <span>设置</span>
                </div>
                <div class="icon-box">
                    <span class="hymicon lq-xiangyoujiantou"></span>
                </div>
            </div>
        </div>
    </div>
</div>
