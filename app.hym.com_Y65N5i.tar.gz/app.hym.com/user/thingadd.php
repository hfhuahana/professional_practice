<div id="thingadd-box">
    <div class="head">
        <div class="return-box">
            <span class="hymicon lq-fanhui"></span>
        </div>
        <div class="title">
            <span></span>
        </div>
    </div>
    <div class="add-box">
        <div class="card">
            <div class="title-box">
                <div class="title">
                    <span class="hymicon lq-jibenxinxi"></span>
                    <span>基本信息</span>
                </div>
            </div>
            <div class="contain">
                <div class="itemline">
                    <div class="label">
                        <span class="must">物品名称</span>
                    </div>
                    <input id="addthing_name" maxlength="50" placeholder="请输入物品名称"/>
                </div>
                <div class="itembreak"></div>
                <div class="itemline">
                    <div class="label">
                        <span class="must">物品数量</span>
                    </div>
                    <input id="addthing_num" type="number" placeholder="请输入物品数量"/>
                </div>
                <div class="itembreak"></div>
                <div class="itemline">
                    <div class="label">
                        <span class="optional">物品单位</span>
                    </div>
                    <input id="addthing_dw" placeholder="请输入物品单位" value="个（暂不支持修改）" disabled/>
                </div>
                <div class="itembreak"></div>
                <div class="itemline">
                    <div class="label">
                        <span class="must">选择所属分类</span>
                    </div>
                    <span class="hymicon lq-xiangyou1"></span>
                    <input placeholder="请选择分类" readonly="readonly" id="addthing_boxclass"/>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="title-box">
                <div class="title">
                    <span class="hymicon lq-shijian4"></span>
                    <span>时间信息</span>
                </div>
            </div>
            <div class="contain">
                <div class="itemline">
                    <div class="label">
                        <span class="must">生产日期</span>
                    </div>
                    <span class="hymicon lq-xiangyou1"></span>
                    <input placeholder="请选择生产日期" readonly="readonly" id="addthing_produce_date"/>
                </div>
                <div class="itembreak"></div>
                <div class="itemline">
                    <div class="label">
                        <span class="must">到期时间</span>
                    </div>
                    <span class="hymicon lq-xiangyou1"></span>
                    <input placeholder="请选择到期时间" readonly="readonly" id="addthing_overdue_date"/>
                </div>
                <div class="itembreak"></div>
                <div class="itemline">
                    <div class="label">
                        <span class="must">从生产距到期天数</span>
                    </div>
                    <input type="number" id="addthing_overdue_date_num" placeholder="请输入距离到期天数"/>
                </div>
                <div class="itembreak"></div>
                <div class="itemline">
                    <div class="label">
                        <span class="must">临期时间</span>
                    </div>
                    <span class="hymicon lq-xiangyou1"></span>
                    <input placeholder="请选择临期时间" readonly="readonly" id="addthing_near_date"/>
                </div>
                <div class="itembreak"></div>
                <div class="itemline">
                    <div class="label">
                        <span class="must">临期天数</span>
                    </div>
                    <input id="addthing_near_days" placeholder="请输入临期天数" type="number"/>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="title-box">
                <div class="title">
                    <span class="hymicon lq-beizhu2"></span>
                    <span>备注信息</span>
                </div>
            </div>
            <div class="contain">
                <textarea id="addthing_beizhu" maxlength="1000" placeholder="请输入备注信息(1000字以内)"></textarea>
                <div id="addthing_beizhu_len" class="type-disable">0/1000</div>
            </div>
        </div>
        <div class="btn-box">
            <div class="btn submit" id="sub_addthing">
                <span>确定</span>
            </div>
            <div class="btn edit" id="sub_editthing">
                <span>修改</span>
            </div>
            <div class="btn cancel">
                <span>取消</span>
            </div>
        </div>
    </div>
</div>