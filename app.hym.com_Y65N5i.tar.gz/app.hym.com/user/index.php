<html>
    <head>
        <style>
            html, body{
                -webkit-tap-highlight-color: transparent;
                -webkit-touch-callout: none;
                -webkit-user-select: none;
                height:100%;
                width:100%;
                margin:0;
                padding:0;
                overflow:hidden;
                /*filter:grayscale(1);*/
                user-select:none;
            }
            a{
                text-decoration: none;
            }
        </style>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
        <!--<meta name="viewport" content="width=device-width, initial-scale=1.0">-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        
        <link rel="stylesheet" href="//at.alicdn.com/t/font_3250367_jt5fmncyo5d.css">
        <link rel="stylesheet" href="../assets/user/css/common.css">
        <link rel="stylesheet" type="text/css" href="../assets/common/others/mobileselect/css/mobileSelect.css" />
        <link rel="stylesheet" href="../assets/common/others/swiper/swiper-bundle.min.css"/>
        <script src="../assets/common/others/swiper/swiper-bundle.min.js"></script>

        <script src="../assets/common/others/mobileselect/js/mobileSelect.js" type="text/javascript"></script>
		<script type="text/javascript" src="../assets/common/js/jquery.js"></script>
        <script type="text/javascript" src="../assets/user/js/haoyemao_ready.js?v=<?=time(); ?>"></script>
        <script type="text/javascript" src="../assets/common/others/htmltoimg/js/html2canvas.js"></script>
        <script src="../assets/common/others/clipics/dist/clipic.js"></script>
        <script src="../assets/common/others/haoyemao_api_master/haoyemao-api.js"></script>
        <script src="../assets/common/others/jcookie/jquery.cookie.js"></script>
        <script type="text/javascript" src="../assets/user/js/haoyemao_func.js?v=<?=time(); ?>"></script>
        <script type="text/javascript" src="../assets/user/js/haoyemao_ajax.js?v=<?=time(); ?>"></script>
        <script type="text/javascript" src="../assets/user/js/haoyemao_msg.js?v=<?=time(); ?>"></script>
    </head>
    <body>
        <?php include"head.php";?>
            <div id="loading_page">
                <div class="loading-page">
                    <div class="icon">
                        <span class="hymicon lq-jiazai2">
                    </div>
                </div>
            </div>
            <?php include"pannel-index.php";?>
            <?php include"pannel-boxlist.php";?>
            <?php include"pannel-mine.php";?>
            <?php include"thingadd.php";?>
            <?php include"thinglist.php";?>
            <?php include"thingsearch.php";?>
            <?php include"record.php";?>
            <?php include"feedback-msg.php";?>
            <?php include"./sets.php";?>
        <?php include"foot.php";?>
    </body>
</html>