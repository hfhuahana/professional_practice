<!--头部文件-->
<header class="header">
    <!--<div class="return-box">
        返回的图标
        <span class="hymicon lq-fanhui"></span>
    </div>-->
    <div class="title-box">
        <span>临期提醒APP</span>
    </div>
    <div id="menu-avatar" class="avatar-box">
        <!--头像图片链接-->
        <img class="avatar" id="user_info_avatar_menu"src="../public/avatar/avatar.jpg"/>
    </div>
    <div id="menu-mini">
        <ul>
            <li id="turnto_mine">
                个人中心
            </li>
            <hr class="line">
            <li id="exit">
                退出登录
            </li>
        </ul>
    </div>
</header>