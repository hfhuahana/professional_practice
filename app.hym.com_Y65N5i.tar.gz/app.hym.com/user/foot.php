<footer class="footer">
    <div class="tabs">
        <div class="tabs-item this"  id="to_index">
            <div class="icon">
                <span class="hymicon lq-shouye2"></span>
            </div>
            <div class="label">
                <span>首页</span>
            </div>
        </div>
        <div class="tabs-item"  id="to_boxlist">
            <div class="icon">
                <span class="hymicon lq-xiangzi"></span>
            </div>
            <div class="label">
                <span>箱子</span>
            </div>
        </div>
        <div class="tabs-item" id="to_mine">
            <div class="icon">
                <span class="hymicon lq-wode"></span>
            </div>
            <div class="label">
                <span>我的</span>
            </div>
        </div>
    </div>
</footer>