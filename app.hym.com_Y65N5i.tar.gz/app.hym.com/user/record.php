<div id="record-box">
    <div class="head">
        <div class="return-box">
            <span class="hymicon lq-fanhui"></span>
        </div>
        <div class="title">
            <span>物品记录</span>
        </div>
    </div>
    <div class="info">
        <span id="record_thing_name">默认物品</span>
        <span>--</span>
        <span>共有</span>
        <span id="record_num"></span>
        <span>条记录</span>
    </div>
    <div class="list-box">
        <!--<div class="card">
            <div class="time">
                <div class="dot">
                    <span>●</span>
                </div>
                <span>2022-04-23</span>
                <span>00:00:00</span>
            </div>
            <div class="text">
                <div class="line">
                    <div></div>
                </div>
                <div class="detail">
                    <p>创建了物品</p>
                    <p>创建了物品</p>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="time">
                <div class="dot">
                    <span>●</span>
                </div>
                <span>2022-04-23</span>
                <span>00:00:00</span>
            </div>
            <div class="text">
                <div class="line">
                    <div></div>
                </div>
                <div class="detail">
                    <p>创建了物品创建了物品创建了物品创建了物品创建了物品创建了物品创建了物品创建了物品创建了物品创建了物品</p>
                    <p>创建了物品</p>
                </div>
            </div>
        </div>-->
    </div>
</div>