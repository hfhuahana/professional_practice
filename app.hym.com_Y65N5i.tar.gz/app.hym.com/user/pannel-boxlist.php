<div class="pannel-body" id="pannel-boxlist">
    <div class="card-box">
        <div id="boxlist-loading-box" class="loading-boxes">
            <div class="icon">
                <span class="hymicon lq-loading"></span>
            </div>
            <div class="text">
                <span>正在加载中··</span>
            </div>
        </div>
    </div>
    <div class="tool-box">
        <div id="addbtn" class="toolbtn" style="width:92%;">
            <div class="ans">
                <span class="hymicon lq-tianjia"></span>
                <span>添加</span>
            </div>
        </div>
        <!--<div id="sortbtn" class="toolbtn">-->
        <!--    <div class="ans">-->
        <!--        <span class="hymicon lq-paixu2"></span>-->
        <!--        <span>排序</span>-->
        <!--    </div>-->
        <!--</div>-->
    </div>
    <!--添加模块-->
    <div id="addclass-box">
        <div class="head">
            <div class="return-box">
                <span class="hymicon lq-fanhui"></span>
            </div>
            <div class="title">
                <span>箱子添加</span>
            </div>
        </div>
        <div class="add-box">
            <div class="card">
                <div class="title-box">
                    <div class="title">
                        <span class="hymicon lq-jibenxinxi"></span>
                        <span>基本信息</span>
                    </div>
                </div>
                <div class="contain">
                    <div class="itemline">
                        <div class="label">
                            <span class="must">箱子名称</span>
                        </div>
                        <input id="addclass_name" maxlength="10" placeholder="请输入箱子名称"/>
                    </div>
                    <div class="itembreak"></div>
                    <div id="addclass_name_len" class="type-disable">0/10</div>
                </div>
            </div>
            <div class="card">
                <div class="title-box">
                    <div class="title">
                        <span class="hymicon lq-beizhu2"></span>
                        <span>备注信息</span>
                    </div>
                </div>
                <div class="contain">
                    <textarea id="addclass_beizhu" maxlength="100" placeholder="请输入备注信息(100字以内)"></textarea>
                    <div id="addclass_beizhu_len" class="type-disable">0/100</div>
                </div>
            </div>
            <div class="submit-box">
                <div id="sub_addclass" class="subbtn">
                    确定
                </div>
                <div id="cancel_addclass" class="subbtn">
                    取消
                </div>
            </div>
        </div>
    </div>
    <div class="shade"></div>
</div>