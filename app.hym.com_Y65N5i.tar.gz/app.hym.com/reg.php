<html>
    <head>
        <style>
            html, body{
                -webkit-tap-highlight-color: transparent;
                -webkit-touch-callout: none;
                -webkit-user-select: none;
                height:100%;
                width:100%;
                margin:0;
                padding:0;
                overflow:hidden;
                user-select:none;
                background-color: rgba(238,238,238,1);
                /*background-color: rgba(245,245,220,1);*/
            }
            a{
                text-decoration: none;
            }
        </style>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="//at.alicdn.com/t/font_3250367_9neg1ddnm6n.css">
        
        <link rel="stylesheet" href="../assets/index/css/msg.css">
        <link rel="stylesheet" href="../assets/index/css/reg.css">
        
        <link rel="stylesheet" href="../assets/index/css/reg_code.css">
        
        <!--短信验证码的js文件-->
        <script type="text/javascript" src="../assets/index/js/haoyemao-code.js"></script>
        <script type="text/javascript" src="../assets/index/js/haoyemao-ecode.js"></script>
        <script type="text/javascript" src="../assets/index/js/haoyemao-pcode.js"></script>
        
        <script type="text/javascript" src="../assets/index/js/ajax.js"></script>
		<script type="text/javascript" src="../assets/index/js/jquery.cookie.js"></script>
		
		<script type="text/javascript" src="../assets/index/js/msg.js"></script>
		<script type="text/javascript" src="../assets/index/js/reg.js"></script>
		
		
    </head>
    <body>
        <!--head_reg.php的内容-->
        <header id="header-reg">
            <div class="return-box">
                <span class="test hymicon lq-fanhui"></span>
            </div>
            <div class="progress-box">
                <div class="progress-step"></div>
            </div>
        </header>
        <div id="feedback-msg"></div>
        <!--form_reg_step1.php的内容-->
        <div id="reg_data_step1">
            <div class="reg_mobilephone">
                <div class="reg_tip"><p>注&emsp;册</p></div>
                <div  class="reg_input_step1">
                    <a class="area_data" href="#">+86</a>
                    <input type="number" id="step1_tele_input" placeholder="手机号" maxlength="11" />
                    <div class="reg_logo_step1_delet"><span  class="test hymicon lq-chahao1"></span></div>
                </div>
            </div>
            <div class="accord_box"><input type="checkbox" name="accord" id="step1_accord_input" checked="checked" style="margin-left:5px;"><div class="accord_span">我已经阅读并同意该协议</div></div>
            <div class="next_step">
                <span class="next_form" href="#">下一步</span>
            </div>
        </div>
        
        <!--form_reg_step2.php的内容-->
        <div id="reg_data_step2">
            <div class="reg_mobilephone">
                <div class="reg_tip"><span></span></div>
                <!--用199*****988进行注册-->
                <div  class="reg_input_step2" >
                    <input type="number" placeholder="手机验证码" id="step2_reg_code">
                </div>
                <!--<span class="reg_code">点击发送验证码</span>-->
                <input type="button" id="reg_note_btn" value="获取验证码"/>
                    
            </div>
            <div class="next_step">
                <a class="next_form" href="#">下一步</a>
            </div>
        </div>
        
        
        <!--form_reg_step3.php的内容-->
        <div id="reg_data_step3">
            <div class="reg_mobilephone">
                <div class="reg_tip"><p>绑定邮箱账号</p></div>
                <div  class="reg_input_step3" >
                    <input type="text" id="reg_step3_email" placeholder="邮箱"/>
                    <div class="reg_logo_step3_delet"><span  class="test hymicon lq-chahao1"></span></div>
                    
                </div>
            </div>
            <div class="next_step">
                <a class="next_form" href="#">下一步/跳过</a>
            </div>
        </div>
        
        <!--form_reg_step4.php的内容-->
        <div id="reg_data_step4">
            <div class="reg_mobilephone">
                <div class="reg_tip"><span>请设置账号密码</span></div>
                <div  class="reg_input_step4" >
                    <input type="password" id="reg_step4_password" placeholder="密码" maxlength="16">
                    <div class="reg_logo_step4_delet"><span  class="test hymicon lq-chahao1"></span></div>
                    <div class="reg_logo_switch" id="eye"><span  class="test hymicon lq-yincang"></span></div>
                </div>
                <div class="reg_hard">
                    <!--<div class="cover"></div>-->
                    <div class="show">
                        <div  class="reg_hard_lowLevel"></div>
                        <div  class="reg_hard_midLevel"></div>
                        <div  class="reg_hard_finLevel"></div>
                    </div>
                </div>
                <div class="reg_hard_size">
                    简单:这种程度的密码被盗是早晚的事！
                </div>
            </div>
            <div class="next_step">
                <a class="next_form" href="#">下一步</a>
            </div>
        </div>
        
        <!--form_reg_step5.php的内容-->
        <div id="reg_data_step5">
            <div class="reg_mobilephone">
                <div class="reg_tip"><span>请再次输入密码</span></div>
                <div  class="reg_input_step5" >
                    <input type="password" placeholder="password" id="reg_step5_password_again" maxlength="16">
                    <div class="reg_logo_step5_delet"><span  class="test hymicon lq-chahao1"></span></div>
                    <div class="reg_logo_switch" id="eye"><span  class="test hymicon lq-yincang"></span></div>
                </div>
            </div>
            <div class="next_step">
                
                <a class="next_form" href="#">完成</a>
            </div>
        </div>
        <div id="xieyi">
            <div class="head-box">
                <div class="title">
                    <span>协议说明</span>
                </div>
                <div class="return">
                    <span class="hymicon lq-chacha2"></span>
                </div>
            </div>
            <div class="text-body">
                <div>
                    <p>用户注册服务协议</p>
                </div>
            </div>
        </div>
    </body>
</html>