<html>
    <head>
        <style>
            html, body{
                -webkit-tap-highlight-color: transparent;
                -webkit-touch-callout: none;
                -webkit-user-select: none;
                height:100%;
                width:100%;
                margin:0;
                padding:0;
                overflow:hidden;
                user-select:none;
            }
            a{
                text-decoration: none;
            }
        </style>
        <meta charset="UTF-8">
        <META HTTP-EQUIV="pragma" CONTENT="no-cache"> 
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <link rel="stylesheet" href="//at.alicdn.com/t/font_3250367_9neg1ddnm6n.css">
        <!--<link rel="stylesheet" href="//at.alicdn.com/t/font_3250367_e8vlnkey0ma.css?v=2">-->
        <link rel="stylesheet" href="./assets/index/css/login_code.css">
        <link rel="stylesheet" href="./assets/index/css/msg.css">

        <link rel="stylesheet" href="./assets/index/css/login.css">
		
		<!--短信验证码的js文件-->
		<script type="text/javascript" src="./assets/index/js/haoyemao-pcode.js"></script>
		
		<script type="text/javascript" src="./assets/index/js/haoyemao-ecode.js"></script>
		
		<script type="text/javascript" src="./assets/index/js/haoyemao-code.js"></script>
		
		<script type="text/javascript" src="./assets/index/js/ajax.js"></script>
		<script type="text/javascript" src="./assets/common/others/jcookie/jquery.cookie.js"></script>
		
		<script type="text/javascript" src="./assets/index/js/msg.js"></script>
		
		<script type="text/javascript" src="./assets/index/js/login.js"></script>
		
    </head>
    <body>
        
        <!--logo.php内容-->
        <div id="logo_login">
            <div>登&emsp;录</div>
            <!--<img class="logo" src="./public/avatar/demo.jpg"/>-->
        </div>
        <div id="feedback-msg"></div>
        <!--form_login.php内容-->
        <div id="login_data">
            <div class="login_input">
                <div class="login_name_data">
                    <div class="login_name_logo">
                        <img src="../public/avatar/avatar.jpg" id="user_login_img">
                    </div>
                    <input type="text" id="login_name" placeholder="手机号/邮箱账号">
        
                    <div class="login_mobile_close"><span  class="test hymicon lq-chahao1"></span></div>
                </div>
                <div class="login_passport_data">
                    <div class="login_passport_logo">
                        <span  class="test hymicon lq-14"></span>
                    </div>
                    <input type="password" id="login_password" placeholder="密码" maxlength="16">
        
                    <div class="login_logo_close"><span  class="test hymicon lq-chahao1"></span></div>          
                    <div class="login_logo_switch" id="eye"><span  class="test hymicon lq-yincang"></span></div>
                </div>
                <div class="login_to_findback">
                    <input type="checkbox" name="accord_seven" id="login_seven" checked="checked"><div class="login_seven_span">七天免登录</div>
                    <div id="findback_passport"><a href="findback.php">找回密码</a></div>
                </div>
            </div>
            <div class="login_button" id="login_enter">
                <span>确定</span>
            </div>
        </div>
        
        <!--foot_login.php内容-->
        <div id="foot_login">
            <div class="login_mobile">手机验证码登录</div>
            <div class="login_email">邮箱验证码登录</div>
            <div class="login_to_reg"><a href = "reg.php">注册新账号</a></div>
        </div>
        
        <!--login_mobile_hide.php内容-->
        <div id="login_mobile_note">
            <div class="retuen_step">
                <span class="test hymicon lq-xiala1"></span>
            </div>
            
            <div class="login_mobile_input_hide">
                <input type="text" placeholder="输入手机号" id="login_mobile_input">
                <div class="dele_mobile_logo"><span  class="test hymicon lq-chahao1"></span></div>
            </div>
            <div class="login_mobile_note_hide">
                <div  class="login_input_hide" >
                    <input type="number" maxlength="6" placeholder="identityCode" id="hide_mobile_code">
                    
                </div>
                <!--<span class="reg_code">点击发送验证码</span>-->
                <input type="button" id="login_mobile_btn_hide" value="获取验证码" />
            </div>
            <div class="finish_mobile_hide">
                完成验证
            </div>
        </div>
        
        <!--login_email_hide.php内容-->
        <div id="login_email_note">
            <div class="retuen_step">
                <span class="test hymicon lq-xiala1"></span>
            </div>
            
            <div class="login_email_input_hide">
                <input type="text" placeholder="输入邮箱账号" id="login_email_input">
                <div class="dele_email_logo"><span  class="test hymicon lq-chahao1"></span></div>
            </div>
            <div class="login_email_note_hide">
                <div  class="login_input_hide2" >
                    <input type="number" maxlength="6" placeholder="identityCode" id="hide_email_code">
                </div>
                <!--<span class="reg_code">点击发送验证码</span>-->
                <input type="button" id="login_email_btn_hide" value="获取验证码" />
            </div>
            <div class="finish_email_hide">
                完成验证
            </div>
        </div>
        
    </body>
</html>